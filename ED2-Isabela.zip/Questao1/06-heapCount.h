int  heapCount (HEAP* heap)
{   return heap->size;
}
