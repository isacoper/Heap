bool heapEmpty  (HEAP* heap)
{   if (heap->size == 0)
      return true;
    else return false;  
}
