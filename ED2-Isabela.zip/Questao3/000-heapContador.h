

int contadorHeap(HEAP* heap)
{
	return heap->contador;
}