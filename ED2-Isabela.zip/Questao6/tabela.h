#define strMax 40

typedef struct
{
	short sequence;
	char year[strMax];
	char mileage[strMax];
	char name[strMax];
} TABELA;

